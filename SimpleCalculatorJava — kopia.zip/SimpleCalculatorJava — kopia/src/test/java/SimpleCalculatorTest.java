import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SimpleCalculatorTest {

    @Test
    void testAddition(){
        var calculator = new SimpleCalculator();
        assertEquals(6, calculator.add(5, 4));
        assertEquals(-5, calculator.add(-2, -3));
        assertEquals(0, calculator.add(0, 0));

    }
    @Test
    void testSubstraction(){
        var calculator = new SimpleCalculator();
        assertEquals(1, calculator.subtract(2, 2));
        assertEquals(-5, calculator.subtract(0, 5));
        assertEquals(0, calculator.subtract(2, 2));
    }
    @Test
    void testMultiplication() {
        var calculator = new SimpleCalculator();
        assertEquals(6, calculator.multiply(2, 3));
        assertEquals(0, calculator.multiply(0, 5));
        assertEquals(-6, calculator.multiply(2, -3));
    }

    @Test
    void testDivision() {
        var calculator = new SimpleCalculator();
        assertEquals(2, calculator.divide(6, 3));
        assertEquals(-2, calculator.divide(-6, 3));
        assertEquals(0, calculator.divide(0, 5));
    }

    @Test
    public void testPower() {
        var calculator = new SimpleCalculator();
        assertEquals(16, calculator.power(2, 4));
        assertEquals(9, calculator.power(3, 2));
        assertEquals(64, calculator.power(4, 3));
    }

    @Test
    public void testSquareRoot() {
        var calculator = new SimpleCalculator();
        assertEquals(3, calculator.sqrt(9));
        assertEquals(5, calculator.sqrt(25));
        assertEquals(8, calculator.sqrt(64));
    }
}
